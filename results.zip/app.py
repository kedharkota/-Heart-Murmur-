"""
Cardiac AI Analysis System
YOLO11n-seg (Exp2) Segmentation + Gemini 2.5 Flash Report Generation
Dual EF: 2-Image Area Proxy | 4-Image Simpson's Biplane
"""

import streamlit as st
from google import genai
from google.genai import types
from ultralytics import YOLO
import cv2
import numpy as np
from PIL import Image
from pathlib import Path
import time
import os
from dotenv import load_dotenv

# ─── Config ───────────────────────────────────────────────────────────────────
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
gemini_client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None

YOLO_MODEL_PATH = "runs/segment/exp2_4060_yolo11n/weights/best.pt"
GEMINI_MODEL = "gemini-2.5-flash"
IMGSZ = 640
CLASS_NAMES = {0: "LV", 1: "Myocardium", 2: "LA"}
CLASS_COLORS = {0: (255, 50, 50), 1: (50, 255, 50), 2: (50, 100, 255)}

EF_NORMAL = 55
EF_MILD = 40
EF_REDUCED = 30


# ─── Load YOLO ────────────────────────────────────────────────────────────────
@st.cache_resource
def load_yolo():
    model = YOLO(YOLO_MODEL_PATH)
    return model


# ─── YOLO Inference ───────────────────────────────────────────────────────────
def run_yolo_inference(image_array, yolo_model, frame_type="ED"):
    """Run YOLO11n-seg on a single image, return annotated image + detections + LV mask."""
    orig_h, orig_w = image_array.shape[:2]
    results = yolo_model.predict(image_array, imgsz=IMGSZ, device=0, verbose=False)
    result = results[0]

    annotated = image_array.copy()
    lv_mask = np.zeros((IMGSZ, IMGSZ), dtype=np.uint8)
    detections = {}

    for cls_id, name in CLASS_NAMES.items():
        detections[name] = {
            "detected": False,
            "confidence": 0.0,
            "mask_area_px": 0,
        }

    if result.masks is not None and len(result.masks) > 0:
        for j in range(len(result.masks)):
            cls_id = int(result.boxes.cls[j].item())
            conf = float(result.boxes.conf[j].item())
            name = CLASS_NAMES.get(cls_id)
            if name is None:
                continue

            pts_xy = result.masks.xy[j].copy()
            pts_draw = pts_xy.astype(np.int32)

            # Draw filled mask with transparency
            overlay = annotated.copy()
            color = CLASS_COLORS[cls_id]
            cv2.fillPoly(overlay, [pts_draw], color)
            cv2.addWeighted(overlay, 0.4, annotated, 0.6, 0, annotated)
            cv2.drawContours(annotated, [pts_draw], -1, color, 2)

            # Compute pixel area on IMGSZ×IMGSZ grid
            pts_scaled = pts_xy.copy()
            pts_scaled[:, 0] = pts_scaled[:, 0] * IMGSZ / orig_w
            pts_scaled[:, 1] = pts_scaled[:, 1] * IMGSZ / orig_h
            pts_int = pts_scaled.astype(np.int32)
            area_mask = np.zeros((IMGSZ, IMGSZ), dtype=np.uint8)
            cv2.fillPoly(area_mask, [pts_int], 1)
            area_px = int(area_mask.sum())

            # Store best detection per class
            if conf > detections[name]["confidence"]:
                detections[name] = {
                    "detected": True,
                    "confidence": conf,
                    "mask_area_px": area_px,
                }

            # Keep LV binary mask for Simpson's
            if cls_id == 0:
                lv_mask = np.maximum(lv_mask, area_mask)

    # Add frame label
    cv2.putText(
        annotated, f"{frame_type} Frame", (10, 30),
        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2,
    )

    return annotated, detections, lv_mask


# ─── EF: 2D Area Proxy (2-image mode) ────────────────────────────────────────
def calculate_ef_area_proxy(ed_detections, es_detections):
    """Calculate EF from LV pixel areas using 2D area proxy. Units cancel in ratio."""
    ed_lv = ed_detections.get("LV", {})
    es_lv = es_detections.get("LV", {})
    ed_area = ed_lv.get("mask_area_px", 0)
    es_area = es_lv.get("mask_area_px", 0)

    ef_calculable = (
        ed_lv.get("detected", False)
        and es_lv.get("detected", False)
        and ed_area > es_area
    )

    ef = ((ed_area - es_area) / ed_area * 100) if ef_calculable else None

    ef_category = _ef_category(ef)

    ed_conf = ed_lv.get("confidence", 0)
    es_conf = es_lv.get("confidence", 0)
    quality = _image_quality((ed_conf + es_conf) / 2)

    return {
        "method": "2D Area Proxy",
        "ed_lv_area_px": ed_area,
        "es_lv_area_px": es_area,
        "ef_percent": round(ef, 1) if ef is not None else None,
        "ef_category": ef_category,
        "image_quality": quality,
        "ef_calculable": ef_calculable,
    }


# ─── EF: Simpson's Biplane (4-image mode) ────────────────────────────────────
def lv_area_and_length(mask):
    """Compute LV area (pixel count) and long-axis length (pixels) from binary mask."""
    area = int(mask.sum())
    if area == 0:
        return 0, 0
    rows = np.where(mask.any(axis=1))[0]
    length = int(rows[-1] - rows[0]) if len(rows) > 1 else 1
    return area, length


def simpsons_biplane_ef(a4ed, a2ed, l4ed, l2ed, a4es, a2es, l4es, l2es):
    """Compute EF via Simpson's Biplane. Pixel units cancel in ratio."""
    l_ed = (l4ed + l2ed) / 2.0
    l_es = (l4es + l2es) / 2.0
    if l_ed <= 0 or l_es <= 0:
        return None, None, None
    edv = (8.0 * a4ed * a2ed) / (3.0 * np.pi * l_ed)
    esv = (8.0 * a4es * a2es) / (3.0 * np.pi * l_es)
    if edv <= 0:
        return None, None, None
    ef = np.clip(((edv - esv) / edv) * 100.0, 0.0, 100.0)
    return float(ef), float(edv), float(esv)


def calculate_ef_simpsons(lv_masks, all_detections):
    """Calculate EF from 4 LV masks using Simpson's Biplane."""
    a4ed, l4ed = lv_area_and_length(lv_masks["4CH_ED"])
    a2ed, l2ed = lv_area_and_length(lv_masks["2CH_ED"])
    a4es, l4es = lv_area_and_length(lv_masks["4CH_ES"])
    a2es, l2es = lv_area_and_length(lv_masks["2CH_ES"])

    if any(a == 0 for a in [a4ed, a2ed, a4es, a2es]):
        return {
            "method": "Simpson's Biplane",
            "ef_percent": None,
            "ef_category": "Unable to calculate",
            "ef_calculable": False,
            "ed_lv_area_px": 0,
            "es_lv_area_px": 0,
            "image_quality": "Poor",
        }

    ef, edv, esv = simpsons_biplane_ef(a4ed, a2ed, l4ed, l2ed, a4es, a2es, l4es, l2es)

    # Representative pixel areas (average of 2CH+4CH)
    ed_area_px = round((a4ed + a2ed) / 2)
    es_area_px = round((a4es + a2es) / 2)

    # Average confidence across all 4 frames
    confs = [
        all_detections[k].get("LV", {}).get("confidence", 0)
        for k in ["4CH_ED", "2CH_ED", "4CH_ES", "2CH_ES"]
    ]
    avg_conf = sum(confs) / len(confs)

    return {
        "method": "Simpson's Biplane",
        "ed_lv_area_px": ed_area_px,
        "es_lv_area_px": es_area_px,
        "edv_px": round(edv, 1) if edv else None,
        "esv_px": round(esv, 1) if esv else None,
        "ef_percent": round(ef, 1) if ef is not None else None,
        "ef_category": _ef_category(ef),
        "image_quality": _image_quality(avg_conf),
        "ef_calculable": ef is not None,
    }


# ─── EF helpers ───────────────────────────────────────────────────────────────
def _ef_category(ef):
    if ef is None:
        return "Unable to calculate"
    if ef >= EF_NORMAL:
        return "Normal (≥55%)"
    if ef >= EF_MILD:
        return "Mildly Reduced (40-54%)"
    if ef >= EF_REDUCED:
        return "Reduced (30-39%)"
    return "Severely Reduced (<30%)"


def _image_quality(avg_conf):
    if avg_conf >= 0.85:
        return "Good"
    if avg_conf >= 0.65:
        return "Fair"
    return "Poor"


# ─── Advanced Gemini Prompt Builder ───────────────────────────────────────────
def build_advanced_prompt(ed_detections, es_detections, ef_data):
    """Build prompt with Role + 3-Shot Few-Shot + CoT + Structured Output."""
    method = ef_data["method"]
    prompt = f"""You are a board-certified cardiologist with 15 years of \
echocardiography experience at a major academic medical center. \
You are reviewing AI-assisted cardiac segmentation results from a \
YOLO11n deep learning model trained on the CAMUS echocardiogram dataset. \
The EF was calculated using the {method} method. \
Generate a structured clinical cardiac analysis report.

IMPORTANT: All area measurements below are in PIXELS (from a 640x640 segmentation grid), \
NOT in cm². Do not interpret pixel areas as physical dimensions. \
Focus your analysis on the EF percentage (which is dimensionless and valid), \
detection confidence scores, and relative area changes between ED and ES frames.

=== FEW-SHOT EXAMPLES ===

--- EXAMPLE 1: Normal Cardiac Function ---
ED Frame: LV=detected(conf=92%, area=43900px), Myo=detected, LA=detected
ES Frame: LV=detected(conf=90%, area=18950px), Myo=detected, LA=detected
EF: 56.8% | Quality: Good

Reasoning:
Step 1 - LV detected in both frames with high confidence. Reliable segmentation.
Step 2 - Substantial area reduction from ED to ES indicates good contractility.
Step 3 - EF 56.8% is within normal range (≥55%). Normal systolic function.
Step 4 - Myocardium and LA detected in both frames. Complete cardiac view.
Step 5 - Normal cardiac function. No red flags.

## FINDINGS
Left Ventricle detected in both ED and ES frames with high confidence
(92% and 90%). Significant LV area reduction between ED and ES frames
indicates normal contractile function. All three cardiac structures —
LV, Myocardium, and Left Atrium — were successfully segmented in both
frames, confirming complete visualization of key anatomy.

## INTERPRETATION
The ratio of LV area change between diastole and systole is consistent
with normal ventricular contraction. High segmentation confidence suggests
reliable endocardial border detection. Myocardial wall appears intact
and well-defined in both phases. No structural abnormalities inferred.

## EF ASSESSMENT
**NORMAL — EF: 56.8% (Normal range: ≥55%)**
Normal systolic function. The heart is pumping effectively with adequate
volume ejected per beat.

## RECOMMENDATIONS
Routine clinical follow-up. No urgent intervention required.
Correlation with symptoms and clinical history advised.

## DISCLAIMER
⚠️ AI-assisted analysis only. NOT a substitute for professional diagnosis.

---

--- EXAMPLE 2: Mildly Reduced ---
ED Frame: LV=detected(conf=85%, area=51200px), Myo=detected, LA=detected
ES Frame: LV=detected(conf=82%, area=28200px), Myo=detected, LA=detected
EF: 44.9% | Quality: Fair

Reasoning:
Step 1 - LV detected in both frames. Moderate confidence. Fair quality.
Step 2 - Modest area reduction from ED to ES — reduced contractility.
Step 3 - EF 44.9% below normal. Mildly reduced range (40-54%).
Step 4 - Myo and LA detected. Fair quality may affect precision.
Step 5 - Mildly reduced function. Needs follow-up.

## FINDINGS
LV detected in both frames with moderate confidence (85%, 82%).
The area reduction between ED and ES is less than expected for normal
function. All three cardiac structures detected. Image quality was fair,
which may introduce some measurement uncertainty.

## INTERPRETATION
Reduced LV area change between diastole and systole suggests mildly
impaired contractility. May represent early cardiomyopathy, volume
overload, or other etiology requiring clinical correlation.

## EF ASSESSMENT
**MILDLY REDUCED — EF: 44.9% (Normal: ≥55%)**
Heart failure with mildly reduced EF (HFmrEF) range (40-54%).

## RECOMMENDATIONS
Cardiology referral recommended. Repeat echo with optimized windows.
Clinical workup for underlying cause advised.

## DISCLAIMER
⚠️ AI-assisted analysis only. NOT a substitute for professional diagnosis.

---

--- EXAMPLE 3: Severely Reduced ---
ED Frame: LV=detected(conf=74%, area=58500px), Myo=detected, LA=detected
ES Frame: LV=detected(conf=71%, area=42300px), Myo=detected, LA=detected
EF: 27.7% | Quality: Poor

Reasoning:
Step 1 - LV detected but low confidence. Poor image quality noted.
Step 2 - Minimal area reduction from ED to ES — severely impaired contractility.
Step 3 - EF 27.7% severely reduced (<30%). Critical finding.
Step 4 - Myo and LA detected at low confidence. Quality concern.
Step 5 - Severely reduced function. Urgent review needed.

## FINDINGS
LV detected in both frames but with lower confidence (74%, 71%).
Minimal area change between ED and ES frames indicates severely
impaired ventricular contraction. Poor image quality reduces
measurement certainty.

## INTERPRETATION
Severely reduced contractile function with minimal LV area change
between cardiac phases. Pattern consistent with dilated cardiomyopathy
or advanced ischemic heart disease. Poor image quality warrants
repeat imaging for confirmation.

## EF ASSESSMENT
**SEVERELY REDUCED — EF: 27.7% (Normal: ≥55%)**
Heart failure with reduced EF (HFrEF). EF <30% indicates critical
systolic dysfunction requiring urgent evaluation.

## RECOMMENDATIONS
Urgent cardiology referral. Repeat echo with contrast enhancement.
Comprehensive heart failure workup: BNP, cardiac MRI, coronary assessment.
Do not delay clinical evaluation.

## DISCLAIMER
⚠️ AI-assisted analysis only. NOT a substitute for professional diagnosis.

=== END EXAMPLES ===

Now analyze this patient:

=== PATIENT DATA ===
ED FRAME (End Diastole — heart relaxed):
- LV: {"Detected" if ed_detections.get("LV", {}).get("detected") else "Not Detected"}, \
Confidence={ed_detections.get("LV", {}).get("confidence", 0):.1%}, \
Area={ef_data["ed_lv_area_px"]}px
- Myocardium: {"Detected" if ed_detections.get("Myocardium", {}).get("detected") else "Not Detected"}, \
Confidence={ed_detections.get("Myocardium", {}).get("confidence", 0):.1%}
- LA: {"Detected" if ed_detections.get("LA", {}).get("detected") else "Not Detected"}, \
Confidence={ed_detections.get("LA", {}).get("confidence", 0):.1%}

ES FRAME (End Systole — heart contracted):
- LV: {"Detected" if es_detections.get("LV", {}).get("detected") else "Not Detected"}, \
Confidence={es_detections.get("LV", {}).get("confidence", 0):.1%}, \
Area={ef_data["es_lv_area_px"]}px
- Myocardium: {"Detected" if es_detections.get("Myocardium", {}).get("detected") else "Not Detected"}, \
Confidence={es_detections.get("Myocardium", {}).get("confidence", 0):.1%}
- LA: {"Detected" if es_detections.get("LA", {}).get("detected") else "Not Detected"}, \
Confidence={es_detections.get("LA", {}).get("confidence", 0):.1%}

CALCULATED METRICS:
- EF Method: {method}
- Ejection Fraction: {ef_data["ef_percent"]}% — {ef_data["ef_category"]}
- Image Quality: {ef_data["image_quality"]}
- EF Calculable: {ef_data["ef_calculable"]}

=== CHAIN OF THOUGHT — REASON FIRST ===
Step 1 - LV detection status and confidence in both frames?
Step 2 - How much did LV area reduce from ED to ES? (large reduction = good contractility)
Step 3 - EF value and which category does it fall in?
Step 4 - Myocardium and LA status across both frames?
Step 5 - Overall clinical picture and urgency level?

=== YOUR REPORT ===
Follow the EXACT same format as examples above.
Use these sections with ## markdown headers: FINDINGS, INTERPRETATION, EF ASSESSMENT, RECOMMENDATIONS, DISCLAIMER.
Be DETAILED and thorough in each section:
- FINDINGS: Report every detected structure, its confidence, area measurements, and what they indicate. Note any missing structures.
- INTERPRETATION: Provide clinical interpretation of LV size, wall motion, contractility, structural abnormalities, and how ED/ES areas compare. Discuss what the segmentation quality suggests about image reliability.
- EF ASSESSMENT: State the EF value, its clinical category, what it means for cardiac pump function, and how it compares to normal. Use ⚠️ emoji for abnormal results. Mention the EF calculation method used.
- RECOMMENDATIONS: Give specific clinical next steps — imaging follow-ups, specialist referrals, lab tests, lifestyle considerations, and urgency level.
- DISCLAIMER: Standard AI disclaimer.
Write at least 5-8 sentences per section. Do NOT include reasoning steps in the final report — only the clean sections.
"""
    return prompt


# ─── Gemini Report Generator ─────────────────────────────────────────────────
def generate_report_gemini(prompt):
    """Send prompt to Gemini 2.5 Flash and return clinical report."""
    try:
        response = gemini_client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.3,
                top_p=0.9,
                top_k=40,
                max_output_tokens=4096,
            ),
        )
        return response.text
    except Exception as e:
        err = str(e).lower()
        if "quota" in err or "rate" in err:
            return "❌ API rate limit reached. Please try again in 1 minute."
        if "api key" in err or "invalid" in err or "authenticate" in err:
            return "❌ Invalid API key. Check your .env file."
        return f"❌ Report generation failed: {e}"


# ─── Display helpers ──────────────────────────────────────────────────────────
def _display_ef_metrics(ef_data):
    st.divider()
    st.subheader("Ejection Fraction")

    ef = ef_data["ef_percent"]
    if ef is not None:
        if ef >= EF_NORMAL:
            color = "green"
        elif ef >= EF_MILD:
            color = "orange"
        elif ef >= EF_REDUCED:
            color = "red"
        else:
            color = "darkred"
        st.markdown(
            f"<h1 style='text-align:center; color:{color};'>"
            f"EF: {ef}%</h1>",
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            "<h2 style='text-align:center; color:gray;'>"
            "EF: Unable to calculate</h2>",
            unsafe_allow_html=True,
        )

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Method", ef_data["method"])
    m2.metric("ED LV Area", f"{ef_data['ed_lv_area_px']} px")
    m3.metric("ES LV Area", f"{ef_data['es_lv_area_px']} px")
    m4.metric("Category", ef_data["ef_category"])

    m5, m6 = st.columns(2)
    m5.metric("Image Quality", ef_data["image_quality"])
    if "edv_px" in ef_data and ef_data.get("edv_px"):
        m6.metric("EDV/ESV (px³)", f"{ef_data['edv_px']} / {ef_data['esv_px']}")
    else:
        m6.metric("Area Ratio", f"{ef_data['ed_lv_area_px']} / {ef_data['es_lv_area_px']}")


def _display_detection_badges(ed_det, es_det):
    col_ed, col_es = st.columns(2)
    with col_ed:
        st.markdown("**ED Frame**")
        for name in CLASS_NAMES.values():
            d = ed_det.get(name, {})
            if d.get("detected"):
                st.markdown(
                    f"✅ **{name}** — {d['confidence']:.1%}"
                )
            else:
                st.markdown(f"❌ **{name}** — not detected")
    with col_es:
        st.markdown("**ES Frame**")
        for name in CLASS_NAMES.values():
            d = es_det.get(name, {})
            if d.get("detected"):
                st.markdown(
                    f"✅ **{name}** — {d['confidence']:.1%}"
                )
            else:
                st.markdown(f"❌ **{name}** — not detected")


def _average_detections(det_a, det_b):
    """Average two detection dicts for display."""
    avg = {}
    for name in CLASS_NAMES.values():
        a = det_a.get(name, {})
        b = det_b.get(name, {})
        detected = a.get("detected", False) or b.get("detected", False)
        conf = (a.get("confidence", 0) + b.get("confidence", 0)) / 2
        area_px = (a.get("mask_area_px", 0) + b.get("mask_area_px", 0)) / 2
        avg[name] = {
            "detected": detected,
            "confidence": conf,
            "mask_area_px": area_px,
        }
    return avg


def _report_section(ed_det, es_det, ef_data):
    st.divider()
    st.subheader("📋 Clinical Report Generation")

    with st.expander("🔍 View Prompting Techniques"):
        st.markdown(
            "1. **Role Prompting** — Board-certified cardiologist persona\n"
            "2. **3-Shot Few-Shot** — Normal / Mild / Severe examples\n"
            "3. **Chain of Thought** — 5-step reasoning before report\n"
            "4. **Structured Output** — FINDINGS → INTERPRETATION → "
            "EF ASSESSMENT → RECOMMENDATIONS → DISCLAIMER"
        )

    if not GEMINI_API_KEY:
        st.error("🔴 Cannot generate report — no Gemini API key. Add it to .env")
        return

    if st.button("🔬 Analyze with Gemini", type="primary"):
        with st.spinner("Gemini is analyzing findings..."):
            prompt = build_advanced_prompt(ed_det, es_det, ef_data)
            report = generate_report_gemini(prompt)

        # Styled report container matching template
        st.markdown(
            """
            <div style="
                background-color: #1C2333;
                border: 1px solid #3A3F4B;
                border-radius: 10px;
                padding: 2rem 2.5rem;
                margin: 1rem 0;
            ">
                <h3 style="color: #FAFAFA; margin-top: 0;">📄 Clinical Report</h3>
                <hr style="border-color: #3A3F4B;">
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown(report)
        st.markdown(
            '<hr style="border-color: #3A3F4B;">',
            unsafe_allow_html=True,
        )

        timestamp = time.strftime("%Y%m%d_%H%M%S")
        st.download_button(
            "📥 Download Report as .txt",
            data=report,
            file_name=f"cardiac_report_{timestamp}.txt",
            mime="text/plain",
        )

    # Footer disclaimer
    st.divider()
    st.error(
        "⚠️ **DISCLAIMER**: This is an AI-assisted analysis tool for "
        "educational and research purposes only. It is NOT a substitute "
        "for professional medical diagnosis. Always consult a qualified "
        "healthcare provider for clinical decisions."
    )


# ─── Streamlit UI ─────────────────────────────────────────────────────────────
st.set_page_config(page_title="🫀 Cardiac AI Analysis", page_icon="🫀", layout="wide")

# Sidebar
with st.sidebar:
    st.title("⚙️ Settings")
    st.markdown("**Segmentation Model**")
    st.info("YOLO11n-seg (Exp2, CAMUS)")
    st.markdown("**LLM**")
    st.info("Gemini 2.5 Flash")

    st.divider()
    st.markdown("**Prompting Techniques**")
    st.markdown("✅ Role Prompting")
    st.markdown("✅ 3-Shot Few-Shot")
    st.markdown("✅ Chain of Thought")
    st.markdown("✅ Structured Output")

    st.divider()
    if GEMINI_API_KEY:
        st.success("🟢 Gemini API key loaded")
    else:
        st.error("🔴 No API key — add GEMINI_API_KEY to .env")

    st.divider()
    st.warning(
        "⚠️ **Disclaimer**: AI-assisted analysis only. "
        "NOT a substitute for professional medical diagnosis."
    )

# Main
st.title("🫀 Cardiac AI Analysis System")
st.caption("YOLO11n-seg Segmentation + Gemini 2.5 Flash Report Generation")

# Load model
model = load_yolo()

# Mode selection
mode = st.radio(
    "EF Calculation Mode",
    ["2-Image Mode (Area Proxy)", "4-Image Mode (Simpson's Biplane)"],
    horizontal=True,
)

st.divider()

# ───────────────────── 2-IMAGE MODE ──────────────────────
if mode == "2-Image Mode (Area Proxy)":
    col1, col2 = st.columns(2)
    with col1:
        ed_file = st.file_uploader(
            "📤 Upload ED Frame (heart relaxed — largest)",
            type=["png", "jpg", "bmp"],
            key="ed_2img",
        )
    with col2:
        es_file = st.file_uploader(
            "📤 Upload ES Frame (heart contracted — smallest)",
            type=["png", "jpg", "bmp"],
            key="es_2img",
        )

    if ed_file and es_file:
        ed_img = np.array(Image.open(ed_file).convert("RGB"))
        es_img = np.array(Image.open(es_file).convert("RGB"))

        with st.spinner("Running YOLO segmentation..."):
            ed_ann, ed_det, _ = run_yolo_inference(ed_img, model, "ED")
            es_ann, es_det, _ = run_yolo_inference(es_img, model, "ES")

        # Images row
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.image(ed_img, caption="ED Original", use_container_width=True)
        with c2:
            st.image(ed_ann, caption="ED Segmented", use_container_width=True)
        with c3:
            st.image(es_img, caption="ES Original", use_container_width=True)
        with c4:
            st.image(es_ann, caption="ES Segmented", use_container_width=True)

        # EF calculation
        ef_data = calculate_ef_area_proxy(ed_det, es_det)

        # Warnings
        if not ed_det["LV"]["detected"]:
            st.warning("⚠️ LV not detected in ED frame.")
        if not es_det["LV"]["detected"]:
            st.warning("⚠️ LV not detected in ES frame.")
        if (
            ed_det["LV"]["detected"]
            and es_det["LV"]["detected"]
            and ed_det["LV"]["mask_area_px"] <= es_det["LV"]["mask_area_px"]
        ):
            st.warning(
                "⚠️ ED LV area ≤ ES LV area. "
                "You may have uploaded the frames in the wrong order."
            )

        # Metrics row
        _display_ef_metrics(ef_data)

        # Detection badges
        st.subheader("Detection Summary")
        _display_detection_badges(ed_det, es_det)

        # Report generation
        _report_section(ed_det, es_det, ef_data)

    elif ed_file or es_file:
        st.info("📌 Please upload both ED and ES frames to continue.")


# ───────────────────── 4-IMAGE MODE ──────────────────────
else:
    st.markdown("Upload all **four views** for Simpson's Biplane EF:")
    c1, c2 = st.columns(2)
    with c1:
        f_2ch_ed = st.file_uploader("2CH ED Frame", type=["png", "jpg", "bmp"], key="2ch_ed")
        f_2ch_es = st.file_uploader("2CH ES Frame", type=["png", "jpg", "bmp"], key="2ch_es")
    with c2:
        f_4ch_ed = st.file_uploader("4CH ED Frame", type=["png", "jpg", "bmp"], key="4ch_ed")
        f_4ch_es = st.file_uploader("4CH ES Frame", type=["png", "jpg", "bmp"], key="4ch_es")

    files = {"2CH_ED": f_2ch_ed, "2CH_ES": f_2ch_es, "4CH_ED": f_4ch_ed, "4CH_ES": f_4ch_es}
    uploaded_count = sum(1 for v in files.values() if v is not None)

    if uploaded_count == 4:
        images = {}
        for key, f in files.items():
            images[key] = np.array(Image.open(f).convert("RGB"))

        with st.spinner("Running YOLO segmentation on 4 views..."):
            annotated = {}
            all_det = {}
            lv_masks = {}
            for key, img in images.items():
                frame_type = "ED" if key.endswith("ED") else "ES"
                ann, det, lv_m = run_yolo_inference(img, model, f"{key}")
                annotated[key] = ann
                all_det[key] = det
                lv_masks[key] = lv_m

        # Display images in 2 rows of 4
        st.subheader("2-Chamber Views")
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.image(images["2CH_ED"], caption="2CH ED Original", use_container_width=True)
        with c2:
            st.image(annotated["2CH_ED"], caption="2CH ED Segmented", use_container_width=True)
        with c3:
            st.image(images["2CH_ES"], caption="2CH ES Original", use_container_width=True)
        with c4:
            st.image(annotated["2CH_ES"], caption="2CH ES Segmented", use_container_width=True)

        st.subheader("4-Chamber Views")
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.image(images["4CH_ED"], caption="4CH ED Original", use_container_width=True)
        with c2:
            st.image(annotated["4CH_ED"], caption="4CH ED Segmented", use_container_width=True)
        with c3:
            st.image(images["4CH_ES"], caption="4CH ES Original", use_container_width=True)
        with c4:
            st.image(annotated["4CH_ES"], caption="4CH ES Segmented", use_container_width=True)

        # Simpson's EF
        ef_data = calculate_ef_simpsons(lv_masks, all_det)

        # Warnings for missing LV
        for key in ["4CH_ED", "2CH_ED", "4CH_ES", "2CH_ES"]:
            if not all_det[key]["LV"]["detected"]:
                st.warning(f"⚠️ LV not detected in {key} frame.")

        _display_ef_metrics(ef_data)

        # Detection badges — use averaged ED / ES detections
        ed_det_avg = _average_detections(all_det["4CH_ED"], all_det["2CH_ED"])
        es_det_avg = _average_detections(all_det["4CH_ES"], all_det["2CH_ES"])
        st.subheader("Detection Summary (averaged across views)")
        _display_detection_badges(ed_det_avg, es_det_avg)

        _report_section(ed_det_avg, es_det_avg, ef_data)

    elif uploaded_count > 0:
        st.info(f"📌 {uploaded_count}/4 images uploaded. Please upload all 4 views.")
